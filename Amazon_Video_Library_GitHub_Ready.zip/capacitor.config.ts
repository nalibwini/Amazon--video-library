import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.amazonvideoslibrary.app',
  appName: 'Amazon Video Library',
  webDir: 'www',
  server: { androidScheme: 'https' }
};

export default config;
