Amazon Video Library - frontend prototype connected to the Supabase project. The app uses the publishable Supabase key only; no database password is included.
